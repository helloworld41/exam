package com.capgemini.tcc.Exception;

public class InvalidPatientIdException extends Exception {

	public InvalidPatientIdException(String string) {
		// TODO Auto-generated constructor stub
		System.out.println(string);
	}

}

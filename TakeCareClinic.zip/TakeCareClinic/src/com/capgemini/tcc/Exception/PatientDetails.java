package com.capgemini.tcc.Exception;

public class PatientDetails extends Exception {
	
	public PatientDetails(String msg) {
		System.out.println(msg);
	}

}

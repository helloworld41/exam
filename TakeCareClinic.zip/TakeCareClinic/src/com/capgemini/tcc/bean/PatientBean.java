package com.capgemini.tcc.bean;

import java.sql.Date;

public class PatientBean {

	int Patient_id;
	String Patient_name;
	int age;
	long Phoneno;
	String description;
	Date Consultation_date;
	public int getPatient_id() {
		return Patient_id;
	}
	public void setPatient_id(int patient_id) {
		Patient_id = patient_id;
	}
	public String getPatient_name() {
		return Patient_name;
	}
	public void setPatient_name(String patient_name) {
		Patient_name = patient_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getPhoneno() {
		return Phoneno;
	}
	public void setPhoneno(long phono) {
		Phoneno = phono;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getConsultation_date() {
		return Consultation_date;
	}
	public void setConsultation_date(Date consultation_date) {
		Consultation_date = consultation_date;
	}
	@Override
	public String toString() {
		return "PatientBean [Patient_id=" + Patient_id + ", Patient_name=" + Patient_name + ", age=" + age
				+ ", Phoneno=" + Phoneno + ", description=" + description + ", Consultation_date=" + Consultation_date
				+ "]";
	}
	public PatientBean(int patient_id, String patient_name, int age, int phoneno, String description,
			Date consultation_date) {
		super();
		Patient_id = patient_id;
		Patient_name = patient_name;
		this.age = age;
		Phoneno = phoneno;
		this.description = description;
		Consultation_date = consultation_date;
	}
	public PatientBean() {
		
	}
	
	
}

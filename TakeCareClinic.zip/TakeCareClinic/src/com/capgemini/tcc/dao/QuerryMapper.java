package com.capgemini.tcc.dao;

public interface QuerryMapper {
	public static final String INSERTQUERY="insert into Patient values(Patient_Id_Seq.NEXTVAL,?,?,?,?,?)";
	public static final String SELECTQUERY="select Patient_Id_Seq.NEXTVAL from dual";
	public static final String RETRIVE_ALL_PATIENTDETAILS_QUERY="select * from Patient";

}

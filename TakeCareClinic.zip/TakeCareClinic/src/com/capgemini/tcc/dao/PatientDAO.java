package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;


import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.util.DBUtil;



public class PatientDAO implements IPatientDAO{

	@Override
	public int addPatientDetails(PatientBean patient) {
		// TODO Auto-generated method stub
		//logger.info("start of registerFlat method");
		//logger.info("Inserting registerFlat details");
		Connection conn = DBUtil.getConnection();
		int Patient_id = 0;
		try {
			LocalDate date=LocalDate.now();
			PreparedStatement preparedStatement=conn.prepareStatement(QuerryMapper.INSERTQUERY);
		
			preparedStatement.setString(1, patient.getPatient_name());
			preparedStatement.setInt(2, patient.getAge());
			preparedStatement.setLong(3, patient.getPhoneno());
			preparedStatement.setString(4, patient.getDescription());
			preparedStatement.setDate(5,Date.valueOf(date));
			preparedStatement.executeUpdate();
			
			PreparedStatement preparedStatement1=conn.prepareStatement(QuerryMapper.SELECTQUERY);
			ResultSet rst = preparedStatement1.executeQuery();
			while (rst.next())
				Patient_id = rst.getInt(1);
			patient.setPatient_id(Patient_id);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//logger.info("end of  registerFlat method");
		return Patient_id;
	
	}

	@Override
	public PatientBean getPatientDetails(int patientId) {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConnection();
		PatientBean p = null;
		try {
			PreparedStatement preparedStatement=conn.prepareStatement(QuerryMapper.RETRIVE_ALL_PATIENTDETAILS_QUERY);
			preparedStatement.setInt(1,patientId);
			ResultSet rst =preparedStatement.executeQuery();
			
			while (rst.next()) {
				
				p=new PatientBean();
				p.setPatient_id(rst.getInt(1));
				p.setPatient_name(rst.getString(2));
				p.setAge(rst.getInt(3));
				p.setPhoneno(rst.getLong(4));
				p.setDescription(rst.getString(5));
				p.setConsultation_date(rst.getDate(6));
			
			}
			if( p == null)
			{
				System.out.println("There is no patient with this id");
				return null;
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
		
	
		
	}
	
	

}
